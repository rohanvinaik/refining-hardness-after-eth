Compile exact_counting_point_observation_note.tex with a current LaTeX distribution (pdfLaTeX, XeLaTeX, or Tectonic).
The document uses standard TeX packages and Latin Modern fonts.
For bibliography builds, Tectonic runs BibTeX automatically; with pdfLaTeX run LaTeX, BibTeX, then LaTeX twice.
No manuscript PDF, logs, private source links, or build intermediates are included.
